import pytest
import drill1

class TestDrill1():
    @pytest.mark.parametrize("number, expected", [
        (2,8),
        (5,125),
        (9,729),
        (0,0),
        (-1,-1),
        (-2,-8),
        (-10,-1000),
        (-7,-343),
        (-3,-27),
    ])
    def test_integer_cubes(self, number, expected):
        assert drill1.cube(number) == expected
    
    @pytest.mark.parametrize("number, expected", [
        (1.1, 1.331),
        (0.9, 0.729),
        (-0.06, -0.000216),
        (5.65, 180.362125)
    ])
    def test_float_cubes(self,number, expected):
        assert pytest.approx(drill1.cube(number)) == expected
    
    @pytest.mark.parametrize("number, expected", [
        (2,2),
        (3,6),
        (5,120),
        (0,1)
    ])
    def test_valid_integer_factorial(self, number, expected):
        assert drill1.factorial(number) == expected
    
    @pytest.mark.parametrize("number", [
        -1,
        -200,
        -150,
        -7,
        1.2,
        200.345345,
        150.12123,
        -7.9
    ])
    def test_invalid_factorials(self, number):
        with pytest.raises(ValueError):
            drill1.factorial(number)
    
    @pytest.mark.parametrize("number, expected", [
        (2,1),
        (3,1),
        (5,1),
        (99,2),
        (29,2),
        (101,3),
        (5045,4),
        (123234234,9),
        (0,1)
    ])
    def test_count_digits(self, number, expected):
        assert drill1.count_digits(number) == expected
    
    @pytest.mark.parametrize("scores, target, expected", [
        ({"Exam 1": 43, "Exam 2": 59, "Exam 3": 60, "Exam 4": 90}, 70, 98),
        ({"E1": 90, "E2": 95}, 97, 106),
        ({"E1": 88, "E2": 90, "E3": 94}, 91, 92),
        ({"E1": 0, "E2": 0, "E3": 0, "E4": 0}, 100, 500),
        ({"E1": 0}, 0, 0),
        ({"E1": 0, "E2": 0}, 30, 90),
        ({"E1": 100, "E2": 100, "E3": 100, "E4": 100}, 100, 100),
        ({"E1": 100, "E2": 100}, 90, 70)
    ])
    def test_average_grade(self, scores, target, expected):
        assert drill1.average_grade(scores, target) == expected
    
    @pytest.mark.parametrize("numList, start_pos, end_pos, expected", [
        ([1,2,3,4,5], 1, 3, 24),
        ([2,6,7,8,9,3,0,1,4,132,23], 0, 5, 18144),
        ([7,6,14,10,11,9,12,8,15,5,13], 2,8, 19958400),
        ([1,2,3,0,4,5], 1, 3, 0),
        ([124,1.2,34.12,34.234,0, 52.34,5.234,0, 34.5,2.34,52,3452,34,523,46,34,5654,6,47,67,764,57,54,6,74,56,754], 3,6, 0),
        ([7,6,14,10,11,9,12,8,15,5,0,13], 2,8, 19958400)
    ])
    def test_slice_product_normal(self, numList, start_pos, end_pos, expected):
        assert drill1.slice_product(numList, start_pos, end_pos) == expected
    
    @pytest.mark.parametrize("numList, start_pos, end_pos", [
        ([], 0,1),
        ([1,23423,3736465,2412342,65868,234123,957,7856,856,78,67,856,785,67,856,78,34,52,3434,23,412,3,214], -9,1),
        ([235,23,646,456,74,787,86,97,89,5476,34,24,1215,45,6,48,5,689,678,956,4,345,325,66,4,7868,79,979,87,654], -8,1),
        ([124,1.2,34.12,34.234,52.34,5.234,34.5,2.34,52,3452,34,523,46,34,5654,6,47,67,764,57,54,6,74,56,754], -1,1),
        ([134,6456,123,0,7,45,3,1,3,4,6,7,8,9,0,6,32,2,4,46], -2,1),
        ([1,23423,3736465,2412342,65868,234123,957,7856,856,78,67,856,785,67,856,78,34,52,3434,23,412,3,214], 1,12341234123),
        ([235,23,646,456,74,787,86,97,89,5476,34,24,1215,45,6,48,5,689,678,956,4,345,325,66,4,7868,79,979,87,654], 5,3555),
        ([124,1.2,34.12,34.234,52.34,5.234,34.5,2.34,52,3452,34,523,46,34,5654,6,47,67,764,57,54,6,74,56,754], 2,5000),
        ([134,6456,123,0,7,45,3,1,3,4,6,7,8,9,0,6,32,2,4,46], -2,20),
    ])
    def test_invalid_slice_product(self, numList, start_pos, end_pos):
        with pytest.raises(ValueError):
            assert drill1.slice_product(numList, start_pos, end_pos)
    
    @pytest.mark.parametrize("message, shift, expected", [
        ("Julius Caesar", 3, "Mxolxv Fdhvdu"),
        ("Hello Data Science", 7, "Olssv Khah Zjplujl"),
        ("Can Bob get me a soda", 30, "Ger Fsf kix qi e wshe"),
        ("", 123, ""),
        ("", 5, ""),
        ("", 4, ""),
        ("Julius Caesar", 0, "Julius Caesar"),
        ("Hello Data Science", 0, "Hello Data Science"),
        ("Can Bob get me a soda", 0, "Can Bob get me a soda"),
        ("asdfkjasldfjalrkgjoeirghslkdfgjlkadjflkamjf", 0, "asdfkjasldfjalrkgjoeirghslkdfgjlkadjflkamjf"),
        ("It is the bottom of the ninth", -27, "Hs hr sgd anssnl ne sgd mhmsg"),
        ("Data science is cool", -300, "Pmfm eouqzoq ue oaax"),
        ("Summertime fun", -2, "Qskkcprgkc dsl")
    ])
    def test_encryption(self, message, shift, expected):
        assert drill1.encrypt(message, shift).lower() == expected.lower()
    
    @pytest.mark.parametrize("message, shift, expected", [
        ("Mxolxv Fdhvdu", 3, "Julius Caesar"),
        ("Olssv Khah Zjplujl", 7, "Hello Data Science"),
        ("Ger Fsf kix qi e wshe", 30, "Can Bob get me a soda"),
        ("", 123, ""),
        ("", 5, ""),
        ("", 4, ""),
        ("asdfasdfasdfadsf", 0, "asdfasdfasdfadsf"),
        ("HelsdfgsdfgsdfgsdlodsfgsdfgsdhdScfhjtyjtyjhfjdfience", 0, "HelsdfgsdfgsdfgsdlodsfgsdfgsdhdScfhjtyjtyjhfjdfience"),
        ("CawthrtnmtukyunBosdgsdfgbgdfghdfghetsdgfsdfgsdfgmeasdfgsdfgsodsdfgsdfga", 0, "CawthrtnmtukyunBosdgsdfgbgdfghdfghetsdgfsdfgsdfgmeasdfgsdfgsodsdfgsdfga"),
        ("asdfasdfasdfasdfasdfasdfsdfasdf", 0, "asdfasdfasdfasdfasdfasdfsdfasdf"),
        ("Hs hr sgd anssnl ne sgd mhmsg", -27, "It is the bottom of the ninth"),
        ("Pmfm eouqzoq ue oaax", -300, "Data science is cool"),
        ("Qskkcprgkc dsl", -2, "Summertime fun")
    ])
    def test_decryption(self, message, shift, expected):
        assert drill1.decrypt(message, shift).lower() == expected.lower()